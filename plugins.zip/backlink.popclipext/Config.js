// #popclip
// name: backlink
// language: javascript
const greeting = "https://ahrefs.com/zh/backlink-checker/?input=" + popclip.input.data.urls[0] + "&mod=exact";
if(popclip.input.data.urls[0]){
  popclip.openUrl(greeting)
}else{
  popclip.abort();

}
